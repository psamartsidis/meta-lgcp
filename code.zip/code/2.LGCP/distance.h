void distance(float*,int,int*,int*);
