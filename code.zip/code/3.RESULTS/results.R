# Analysis parameters
setup = read.table('setup.txt')[,1]
K1 = setup[1]
K2 = setup[2]

# Read the file of scalars from 
burnin = read.table('./outputs/burnin.txt')
nBurn = dim(burnin)[1]
hmc = read.table('./outputs/hmc.txt')
nIter = dim(hmc)[1]
nCol = dim(hmc)[2]

pdf('diagnostics.pdf')
par(mar=c(4.1,3.1,3.1,1.1))
par(mfrow=c(2,2))
for (i in 1:K1) {
  plot(hmc[seq(1,nIter,length=1000),nCol],hmc[seq(1,nIter,length=1000),1+i],type='l',ylab=NA,xlab=NA,bty='n',main=bquote(sigma[.(i)]) )
  acf(hmc[,1+i],main=NA,bty='n')
}
for (i in 1:K1) {
  plot(hmc[seq(1,nIter,length=1000),nCol],hmc[seq(1,nIter,length=1000),1+K1+i],type='l',ylab=NA,xlab=NA,bty='n',main=bquote(rho[.(i)]) )
  acf(hmc[,1+K1+i],main=NA,bty='n')
}
for (i in 1:(K1+K2)) {
  plot(hmc[seq(1,nIter,length=1000),nCol],hmc[seq(1,nIter,length=1000),1+2*K1+i],type='l',ylab=NA,xlab=NA,bty='n',main=bquote(beta[.(i)]) )
  acf(hmc[,1+2*K1+i],main=NA,bty='n')
}
par(mfrow = c(2,1))
plot(c(burnin[,nCol-2],hmc[,nCol-2]),type='l',ylab=NA,xlab=NA,bty='n',main='Unnormalised log-posterior' )
abline(v=nBurn,lwd=2,col=2)
plot(c(burnin[,1],hmc[,1]),type='l',ylab=NA,xlab=NA,bty='n',main='HMC stepsize' )
abline(v=nBurn,lwd=2,col=2)
dev.off()

# load libraries and read the mask
library(oro.nifti); library(lattice)
mask = readNIfTI('FSL_2mm.nii') ; mask = 1*(mask >=0.75)
mask_tmp = NULL
mask_dim = dim(mask)
V = sum(mask)

# plot the mean and variance of the spatially varying GPs
options(warn=-1) # because some slices in the mask are empty
levelplot_settings = list(axis.line = list(col = "transparent"))
scales = list(col = "black")
scales = list(col = "black")
breaks = colors = name = NULL
file  = read.table('./outputs/gp_summaries.txt')
for (i in 1:K1) {
  # Mean
  name = paste('mean_',i,'.pdf',sep='')
  mask_tmp = mask
  mask_tmp[mask_tmp==1] = file[,2*(i-1)+1]
  mask_tmp[mask_tmp==0] = NA
  breaks = seq(min(mask_tmp,na.rm=T),max(mask_tmp,na.rm=T),length=256)
  colors = tim.colors(512)[1:256]
  pdf(name)
  for (z in 1:mask_dim[3]) {
    print(levelplot(mask_tmp[,,z],col.regions=colors,at=breaks,xlab='',ylab='',bty='n',par.settings = levelplot_settings))
  }
  dev.off()
  mask_tmp = as.nifti(mask_tmp)
  writeNIfTI(mask_tmp,paste("mean_",i,sep=''))
  # Variance
  name = paste('variance_',i,'.pdf',sep='')
  mask_tmp = mask
  mask_tmp[mask_tmp==1] = file[,2*(i-1)+2]
  mask_tmp[mask_tmp==0] = NA
  breaks = seq(min(mask_tmp,na.rm=T),max(mask_tmp,na.rm=T),length=256)
  colors = tim.colors(512)[1:256]
  pdf(name)
  for (z in 1:mask_dim[3]) {
    print(levelplot(mask_tmp[,,z],col.regions=colors,at=breaks,xlab='',ylab='',bty='n',par.settings = levelplot_settings))
  }
  dev.off()
  mask_tmp = as.nifti(mask_tmp)
  writeNIfTI(mask_tmp,paste("variance_",i,sep=''))
  # Intensity
  name = paste('intensity_',i,'.pdf',sep='')
  mask_tmp = mask
  mask_tmp[mask_tmp==1] = file[,2*(i-1)+1]
  mask_tmp[mask_tmp==0] = NA
  breaks = seq(min(exp(mask_tmp),na.rm=T),max(exp(mask_tmp),na.rm=T),length=256)
  colors = tim.colors(512)[1:256]
  pdf(name)
  for (z in 1:mask_dim[3]) {
    print(levelplot(exp(mask_tmp[,,z]),col.regions=colors,at=breaks,xlab='',ylab='',bty='n',par.settings = levelplot_settings))
  }
  dev.off()
  mask_tmp = as.nifti(mask_tmp)
  writeNIfTI(mask_tmp,paste("intensity_",i,sep=''))
}


if (setup[3]==1) {
  column = 0
  file  = read.table('./outputs/gp_diff.txt')[,1]
  K3 = K1*(K1-1)/2 # how many pairwise combinations
  file = matrix(file,V,K3,byrow=T)
  for (i in 1:(K1-1)) {
    for (j in (i+1):K1) {
      column = column + 1
      if (column<=K3) {
        name = paste('diff_',i,'_',j,'.pdf',sep='')
        mask_tmp = mask
        mask_tmp[mask==1] = file[,column]
        mask_tmp[mask==0] = NA
        breaks = seq(min(mask_tmp,na.rm=T),max(mask_tmp,na.rm=T),length=256)
        colors = tim.colors(256)
        pdf(name)
        for (z in 1:mask_dim[3]) {
          print(levelplot(mask_tmp[,,z],col.regions=colors,at=breaks,xlab='',ylab='',bty='n',par.settings = levelplot_settings))
        }
        dev.off()
        mask_tmp = as.nifti(mask_tmp)
        writeNIfTI(mask_tmp,paste("diff_",i,'_',j,sep=''))
      }
    }
  }
}

# Put warnings back on 
options(warn=0)

