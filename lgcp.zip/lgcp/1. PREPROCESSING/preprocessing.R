# load the libraries
library(oro.nifti)
library(lattice)

# read the cbma.txt data file
cbma = read.table('cbma.txt',header=T); directory = getwd()


# transform the foci coordinates to voxel space
origin = c(90,-126,-72)
cbma$x = round((origin[1]-cbma$x)/2)
cbma$y = round((cbma$y-origin[2])/2)
cbma$z = round((cbma$z-origin[3])/2)

# load the brain mask
mask = readNIfTI('FSL_2mm.nii')
mask = (mask>0.75)*1
dim_old = dim(mask)

# plot the original data
data_tmp = keep = NULL
pdf('original.pdf')
for (i in 1:dim_old[3]) {
  print(levelplot(mask[,,i],asp='iso',scales=list(x=list(draw=F),y=list(draw=F)),xlab='',ylab='',colorkey=F,at=c(-0.1,0.6,1.1),col.regions = c('white','lightgrey'),row.values=1:dim_old[1],column.values=1:dim_old[2],par.settings = list(axis.line = list(col = "transparent"))))
  keep = cbma$z==i
  data_tmp = cbma[keep,]
  trellis.focus("panel", 1, 1, highlight=FALSE)
  lpoints(data_tmp$x+runif(length(data_tmp$x),-0.5,0.5),data_tmp$y+runif(length(data_tmp$y),-0.5,0.5), pch=19, col=2, cex=0.2)
}
dev.off()

# remove the blank space around the brain mask and indicate foci reported in these voxels
boundary = rep(0,dim(cbma)[1]) # in order to spot easily the foci that will be removed
for (i in dim_old[3]:1){
  if (sum(mask[,,i])==0) {
    mask = mask[,,-i]
    boundary[cbma$z==i] = boundary[cbma$z==i]+1
    cbma$z[cbma$z>i] = cbma$z[cbma$z>i]-1 
  }
}
for (i in dim_old[2]:1){
  if (sum(mask[,i,])==0) {
    mask = mask[,-i,]
    boundary[cbma$y==i] = boundary[cbma$y==i]+1
    cbma$y[cbma$y>i] = cbma$y[cbma$y>i]-1 
  }
}
for (i in dim_old[1]:1){
  if (sum(mask[i,,])==0) {
    mask = mask[-i,,]
    boundary[cbma$x==i] = boundary[cbma$x==i]+1
    cbma$x[cbma$x>i] = cbma$x[cbma$x>i]-1 
  }
}
dim_new = dim(mask)

# mark the foci that are outside the brain mask
cbma$z[boundary>0] = 1000
cbma$z[(cbma$x<1)|(cbma$x>dim_new[1])] = 1000
cbma$z[(cbma$y<1)|(cbma$y>dim_new[2])] = 1000
cbma$z[(cbma$z<1)|(cbma$z>dim_new[3])] = 1000

# scan the list of foci to find out which fall inside the brain mask
within_brain = rep(0,dim(cbma)[1])
tmp = NULL
for (i in 1:dim(cbma)[1]) {
  tmp = try( mask[ cbma$x[i] , cbma$y[i] ,cbma$z[i] ] , silent=T)
  within_brain[i] = tmp==1
}
cbma$within = 1*within_brain


# split the data by contrast
contrasts = split(cbma,cbma$Contrast)
N = length(contrasts)

# examine the coordinates of each study one by one to see how many are outside the brain
Z = NULL # the design matrix (INPUT TO THE PROGRAM)
counts = NULL # how many foci per study (INPUT TO THE PROGRAM)
foci = NULL # the list of foci (INPUT TO THE PROGRAM)
cbma_tmp = n = NULL
id = 0
contrast_info = data.frame(ID=rep(NA,N),original=rep(NA,N),final=rep(NA,N)) # id, original counts and final counts 
for (i in 1:N) {
  cbma_tmp = contrasts[[i]]
  n = dim(cbma_tmp)[1]
  contrast_info[i,1] = cbma_tmp$Contrast[1]
  contrast_info[i,2] = n
  contrast_info[i,3] = sum(cbma_tmp$within)
  if (contrast_info[i,3]>0) {
    # arrange the foci
    id = id + 1 
    keep = cbma_tmp$within==1
    cbma_tmp = cbma_tmp[keep,]
    n = dim(cbma_tmp)[1]
    foci = rbind( foci ,  cbind( cbma_tmp$x,cbma_tmp$y,cbma_tmp$z,rep(id,n) )   )
    # counts
    counts  = c(counts,n)
    # design matrix: the covariates with spatially varying effects need to go first
    tmp = cbma_tmp[1,]
    tmp = c(tmp$Valence=='positive' , tmp$Valence=='negative' , tmp$N , tmp$p_correction=='corrected')
    Z = rbind(Z,tmp)
  }
}

# provide a file that shows the original and post-processing number of foci per study
write.table(contrast_info,'info.txt',row.names=F)

# Since the matrix Z will be standardized, it is useful to have the original values
write.table(Z,'Z.txt',row.names=F,col.names=F)


# change the directory to supply the inputs for the program
setwd('../2.LGCP')

# foci file
foci  = data.frame(x=foci[,1],y=foci[,2],z=foci[,3],ID=foci[,4])
write.table(foci,paste(getwd(),'/inputs/foci.txt',sep=''),col.names=F,row.names=F)

# counts file 
write.table(counts,paste(getwd(),'/inputs/counts.txt',sep=''),col.names=F,row.names=F)

# design matrix
Z[,3] = sqrt(Z[,3]) # take square root sample size
Z[,3] = (Z[,3]-mean(Z[,3]))/sd(Z[,3])
Z[,4] = (Z[,4]-mean(Z[,4]))/sd(Z[,4])
write.table(Z,paste(getwd(),'/inputs/Z.txt',sep=''),col.names=F,row.names=F)

# Some starting values for the model parameters
V = 144 * 192*144 # the total number of voxels in the extended brain
K1 = 2 # total number of spatially varying covariates 
K2 = 2 # total number of covariates with homogenous effects
beta = c( log(mean(counts[Z[,1]==1])/(8*V)) , log(mean(counts[Z[,2]==1])/(8*V)) ,rep(0,K2)) # mean of the latent Gaussian process. 
# For multi-type point pattern analyses specify the mean set \beta to the average number of points 
sigma = rep(1,K1) # standard deviation 
rho = rep(1,K1) # correlation decay parameter
gamma = rnorm(K1*V) # errors
write.table(beta,paste(getwd(),'/inputs/beta.txt',sep=''),col.names=F,row.names=F)
write.table(sigma,paste(getwd(),'/inputs/sigma.txt',sep=''),col.names=F,row.names=F)
write.table(rho,paste(getwd(),'/inputs/rho.txt',sep=''),col.names=F,row.names=F)
write.table(gamma,paste(getwd(),'/inputs/gamma.txt',sep=''),col.names=F,row.names=F)

# And finally specify and write some other parameters the program needs to know
# Total number of: voxels, foci, studies, covariates, covariates with spatilly varying effect 
setup = c( prod(dim(mask)) , dim(foci)[1] , dim(Z)[1] , K1+K2 , K1 )
# The mean number of leapfrog steps
setup = c(setup , 50 )
# The seed
setup = c( setup , 4313387630567 )
# The HMC mass parameters for: mean, sd and correlation decay of the GPs, and the coefficients of the spatially homogenous covariates   
setup = c(setup , 9 , 16 , 25 , 200 )
# Whether or not mean standardised posterior differences should be saved
setup = c(setup , 1)
# Write the file           
write.table( setup , paste(getwd(),'/inputs/setup.txt',sep=''),col.names=F,row.names=F)          


# Add some constants to a header file 
cat('',file='kernels.h',append=T,sep='\n')
cat(paste('__const__ int I=',dim(Z)[1],';',sep=''),file='kernels.h',append=T,sep='\n')
cat(paste('__const__ int K_star=',K1+K2,';',sep=''),file='kernels.h',append=T,sep='\n')
cat(paste('__const__ int K=',K1,';',sep=''),file='kernels.h',append=T,sep='\n')
cat(paste('__const__ int TIMES=',ceiling(dim(Z)[1]/floor(256/(K1+K2+1))),';',sep=''),file='kernels.h',append=T,sep='\n')
cat(paste('__const__ int STUDIES=',floor(256/(K1+K2+1)),';',sep=''),file='kernels.h',append=T,sep='\n')
cat(paste('__const__ int CUBLAS_TMP=',ceiling(N/512),';',sep=''),file='kernels.h',append=T,sep='\n')

# plot the data after pre-processing
setwd(directory)
pdf('final.pdf')
for (i in 1:dim_new[3]) {
  print(levelplot(mask[,,i],asp='iso',scales=list(x=list(draw=F),y=list(draw=F)),xlab='',ylab='',colorkey=F,at=c(-0.1,0.6,1.1),col.regions = c('white','lightgrey'),row.values=1:dim_new[1],column.values=1:dim_new[2],par.settings = list(axis.line = list(col = "transparent"))))
  keep = foci$z==i
  data_tmp = foci[keep,]
  trellis.focus("panel", 1, 1, highlight=FALSE)
  lpoints(data_tmp$x+runif(length(data_tmp$x),-0.5,0.5),data_tmp$y+runif(length(data_tmp$y),-0.5,0.5), pch=19, col=2, cex=0.2)
}
dev.off()



# and finally some info for the analysis of the results
write.table(c(K1,K2,setup[length(setup)]),"../3.RESULTS/setup.txt",col.names=F,row.names=F)

